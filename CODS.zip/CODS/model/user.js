const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  userID: String,
  username: String,
  password: String,
  creationDate: { type: Date, default: Date.now },
  updateDate: Date,
  deletionDate: Date,
  adminStatus: { type: Boolean, default: false }
});

module.exports = mongoose.model('User', userSchema);
